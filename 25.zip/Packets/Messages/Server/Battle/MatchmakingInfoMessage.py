from Utils.Writer import Writer


class MatchmakingInfoMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 20405
        self.player = player

    def encode(self):
        self.writeInt(50) # Timer (but it's don't work in v12 :( )
        self.writeInt(6974) # Players founded
        self.writeInt(7777) # Max players
