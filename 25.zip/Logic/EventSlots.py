import time

class EventSlots:
    Timer = 86400
    # map id + 3
    maps = [
        # Status = [3 = Nothing, 2 = Star Token, 1 = New Event]
        {
            'ID': 7,
            'Status': 3,
            'Ended': False,
            'Modifier': 0
        },

        {
            'ID': 32,
            'Status': 3,
            'Ended': False,
            'Modifier': 0
        },

        {
            'ID': 17,
            'Status': 3,
            'Ended': False,
            'Modifier': 0
        },

        {
            'ID': 21,
            'Status': 3,
            'Ended': False,
            'Modifier': 0
        },

        {
            'ID': 35,
            'Status': 3,
            'Ended': False,
            'Modifier': 0
        },

        {
            'ID': 24,
            'Status': 3,
            'Ended': False,
            'Modifier': 0
        },

        {
            'ID': 187,
            'Status': 3,
            'Ended': False,
            'Modifier': 0
        }

    ]